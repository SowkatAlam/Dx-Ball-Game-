package hr.game.dxball;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Canvas;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Created by Mashuk on 9/2/16.
 */
public class StageActivity extends Activity {

    Button st1btn;
    Button st2btn;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.stage);
    }

    @Override
    protected void onStart() {
        super.onStart();


        Button btn = (Button) findViewById(R.id.St2btn);
        
        /*
        	BufferedReader readertemp=null;
			try {
				readertemp=new BufferedReader( new InputStreamReader(this.getAssets().open("stage.txt")));
						
						String line;
						line=readertemp.readLine();
						
						if(line.toString().equals("0"))
						{
							
							btn.setEnabled(false);
						}
						
					
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			*/
			
        btn.setEnabled(false);
        
        
        try {
            File myFile = new File(getFilesDir(),"stageIdentifier.txt");
            if(myFile.exists()) {

                //check whether stage 2 is unlocked or not
                FileInputStream fis = openFileInput("stageIdentifier.txt");
           
                InputStreamReader isr = new InputStreamReader(fis);
                BufferedReader bufferedReader = new BufferedReader(isr);
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    sb.append(line);
                }

                Log.d("file", sb.toString());
          
                
                if (sb.toString().equals("1")) {
                    btn.setEnabled(true);
                }
                
            }
    


        }

        catch (Exception e) {
            e.printStackTrace();
        }
        
        
        
        	

    	
        
    }
    
    @Override
    protected void onResume() {
    	// TODO Auto-generated method stub
    	super.onResume();
    	
    	if(GameCanvas.isstage1fullover==10)
    	{
    		File myFile = new File(getFilesDir(),"stageIdentifier.txt");
            FileOutputStream fileOutputStream = null;

            try
            {

                fileOutputStream = new FileOutputStream(myFile,false);
                fileOutputStream.write("1".getBytes());
                
                 
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }

            finally {
                try {
                    fileOutputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
    	}

    }
    public void StartStage1(View v){
        this.st1btn = (Button)findViewById(R.id.St1btn);
        Intent i = new Intent(StageActivity.this,DxBallActivity.class);
        GameCanvas.stageNo=1;
        GameCanvas.num_of_brick=10;
        GameCanvas.collision_num=0;
        
        
        startActivity(i);
    }
    public void StartStage2(View v){
        this.st2btn = (Button)findViewById(R.id.St2btn);
        Intent i = new Intent(StageActivity.this,DxBallActivity.class);
        GameCanvas.stageNo=2;
        GameCanvas.num_of_brick=15;
        GameCanvas.collision_num=0;
        startActivity(i);

    }


}
