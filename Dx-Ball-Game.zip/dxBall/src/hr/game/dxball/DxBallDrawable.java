package hr.game.dxball;

import static java.lang.Math.abs;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.media.MediaPlayer;
import android.util.Log;
import android.widget.Toast;

public class DxBallDrawable implements Runnable{
	
	Paint paint=new Paint();
	Canvas canvas;
	//float xx=1;
	
	public static int isThreadRunning=0;
	
	float x=0,y=0,dx=+.5f,dy=-.5f;
	float startx,starty;

	private float ballRadius=10;
	
	private float brickx;
	private float bricky=20;
	
	private int num_of_brick;
	
	private Thread t;
	MediaPlayer sound;
	
	float h,w;
	//final Handler handler = new Handler();
	DxBallBar mainBar;
	GameInformation gameInformation;
	//private Thread thisThread;
	DxBallBrick[] brick=new DxBallBrick[200];
	Context context;
	public DxBallDrawable(Canvas temp, float x, float y, float h, float w, GameInformation gameInformation, DxBallBrick[] temp_brick, float brickx, float bricky,Context context,DxBallBar mainBar) {
		// TODO Auto-generated constructor stub
		
		this.canvas=temp;
		
		this.x=x;
		this.y=y;
		this.h=h;
		this.w=w;
		this.startx=x;
		this.starty=y;
		this.gameInformation=gameInformation;
		this.num_of_brick=temp_brick.length;
		this.brickx=brickx;
		this.bricky=bricky;
		this.context=context;
		this.mainBar=mainBar;
		sound=MediaPlayer.create(this.context,R.raw.sound);

		for(int i=0;i<temp_brick.length;i++)
		{
			this.brick[i]=temp_brick[i];

		}
		
		//brick_initialize(temp_brick);
	}
	

	public void draw_rect()
	{
		//canvas.drawRect(100, 100, 200, 200, paint); // x1=100 , y1=100 , x2=200 , y2=200
		
		for(int i=0;i<num_of_brick;i++)
		{
			if(i%2==1)
			{
				paint.setColor(Color.RED);  // what will be the color of painting
				paint.setStyle(Style.FILL); //
			}
			else
			{
				paint.setColor(Color.BLUE);  // what will be the color of painting
				paint.setStyle(Style.FILL); //
			}
			
			if(brick[i].getFlag())
			{
				canvas.drawRect(brick[i].getx(),brick[i].gety(),brick[i].getxx(),brick[i].getyy(), paint); // x1=100 , y1=100 , x2=200 , y2=200
			}
			
		}
		//canvas.drawRect(100, 100, 200, 200, paint); // x1=100 , y1=100 , x2=200 , y2=200
	}
	
	Boolean intersects(float circlex,float circley,float rectx,float recty)
	{
		Log.d("circle info :  ",Float.toString(circlex)+"   "+Float.toString(circley));
		Log.d("rectangle info :  ",Float.toString(rectx)+"   "+Float.toString(recty));
		
		float circleDistancex=abs(circlex - rectx);
		float circleDistancey=abs(circley - recty);
		
		
		
	    if(circleDistancex>(brickx/2+ballRadius)){return false;}
	    
	    if(circleDistancey>(bricky/2+ballRadius)){return false;}
	    
	    if(circleDistancex<=(brickx/2)){return true;}
	    
	    if(circleDistancey<=(bricky/2)){return true;}
	    
	    float cornerDistance=((circleDistancex-brickx/2)*(circleDistancex-brickx/2))+((circleDistancey-bricky/2)*(circleDistancey-bricky/2));
	    
	    return (cornerDistance<=(ballRadius*ballRadius));
	}
	
	
	public void ball_new_track(int index)
	{
		if (((y - ballRadius) <=brick[index].getyy()) && ((y +ballRadius) >= brick[index].gety()) && ((x) >= brick[index].getx()) && ((x) <= brick[index].getxx())) {
			
			dy=-dy;
		}
		else if(((y) <= brick[index].getyy()) && ((y) >= brick[index].gety()) && ((x + ballRadius) >= brick[index].getx()) && ((x -ballRadius) <= brick[index].getxx())) {
			
			dx=-dx;
		}
		
		
	}
	public void collision_detection()
	{
		
			for(int i=0;i<num_of_brick;i++)
			{
				
				
				if(intersects(x,y,brick[i].getx()+(brickx/2), brick[i].gety()+(bricky/2)))
				{	
					if(brick[i].getFlag())
					{
						sound.start();
						ball_new_track(i);
						brick[i].setFlagFalse();
						gameInformation.setScore(gameInformation.getScore()+1);
						GameCanvas.collision_num++;
						
					}
					
				}
				
			}
		
	}
	
	

	
	protected void calculateNextPos(){
		
		
		if(x<=ballRadius)
		{
			dx=-dx;
		}
		else if((y+ballRadius>=mainBar.getBarTop()))
		{
			//if((x>=mainBar.getBarLeft()&&x>=mainBar.getBarHeight()))
			if((x>=mainBar.getBarLeft()&&x<=mainBar.getBarRight()))
			{
				dy=-dy;
			}
			else
			{
				gameInformation.setLife(gameInformation.getLife()-1);
				this.x=(mainBar.getBarLeft()+mainBar.getBarRight())/2;
				this.y=mainBar.getBarTop()-ballRadius/2-10;
				dx=.5f;
				dy=-.5f;
				return ;
				//dx=+4;
				//dy=-4;
			}
			
		}
		
		else if(x+ballRadius>=w)
		{
			dx=-dx;	
			
		}
		
		else if(y<=ballRadius)
		{
			dy=-dy;
			
		}
		
		
		y+=dy;
		x+=dx;
	}


	public void onDraw()
	{
		//xx++;
		
		//canvas.drawText(String.valueOf(xx), 20, 20,paint);
		//paint.setStyle(Style.FILL);
		calculateNextPos();
		//canvas.drawCircle(x,y, ballRadius, paint); // tell to draw circle in the canvas using paint object property
		
		collision_detection();
		//
		
	}


	public void run() {
		// TODO Auto-generated method stub
		
		while(isThreadRunning==0)
		{
			
			try {
				onDraw();
				Thread.sleep(1);
				
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
		
	}
	
	
	public void start ()
	   {
	      
	      if (t == null)
	      {
	         t = new Thread (this,"a");
	         Toast.makeText(context,"Thread Start", Toast.LENGTH_LONG).show();
	         t.start ();
	      } 
	   }
	
	
	public float getX() {
		return x;
	}
	public float getY() {
		return y;
	}
	
	


}
