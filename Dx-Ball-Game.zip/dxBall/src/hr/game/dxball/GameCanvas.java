package hr.game.dxball;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import android.content.Context;
import static java.lang.Math.abs;

import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

public class GameCanvas extends View {

	Paint paint;

	float x=0,y=0,dx=-4,dy=+4;

	private float ballRadius=10;
	float h,w;
	float[] brick_file_info=new float[3];
	public static int column;
	boolean firstTime=true;
	
	Canvas canvas;
	
	float mainBarWidth=140;

	//mashuk
	public static int stageNo;
	public static int num_of_brick;
	//mashuk

	private DxBallBrick[] brick=new DxBallBrick[num_of_brick];

	private float brickx;
	private float bricky=20;
	public static int collision_num=0;
	
	public static int isstage1fullover=0;
	DxBallDrawable ball;
	DxBallBar Bar;
	
	GameInformation gameInformation;
	
	protected void onDraw(Canvas canvas) {// here canvas is the place (mobile screen ) where object should be painted
		
		if(firstTime)
		{
			firstTime=false;
			w=canvas.getWidth();
			h=canvas.getHeight();
			this.canvas=canvas;
			x=w/2;
			y=h-25-ballRadius/2-10;		
			
			
			
			Log.d("w :  ",Float.toString(w));
			Log.d("h :  ",Float.toString(h)); 
			
			
			Log.d("x :  ",Float.toString(x));
			Log.d("y :  ",Float.toString(y));
			
			
			Log.d("w/num_of_brick :  ",Float.toString(w/num_of_brick));
			brickx=w/num_of_brick;
			read();
			initialize_brick();
			
			
			gameInformation=new GameInformation(canvas,2,stageNo,0);
			
			// ball initialization
			

			// this code is for bar initialization
			Bar=new DxBallBar(canvas,h-25,w/2-mainBarWidth/2,mainBarWidth,25);
			
			ball=new DxBallDrawable(canvas,x,y,h,w,gameInformation,brick,brickx,bricky,getContext(),Bar);
			
			ball.start();

		}
		//
		
		//
		
		canvas.drawRGB(255, 255, 255); // tells to set canvas color
		paint.setColor(Color.GREEN);  // what will be the color of painting
		
		paint.setStyle(Style.FILL); //
		
		//ball.onDraw(Bar);
		canvas.drawCircle(ball.getX(),ball.getY(), ballRadius, paint); // tell to draw circle in the canvas using paint object property
		
		
		
		paint.setColor(Color.GREEN);
		
		
		Bar.onDraw();
		
		draw_rect();
		
		gameInformation.onDraw();
		
		gameOver();
		
		invalidate();
	}
	
	public void draw_rect()
	{
		//canvas.drawRect(100, 100, 200, 200, paint); // x1=100 , y1=100 , x2=200 , y2=200
		
		for(int i=0;i<num_of_brick;i++)
		{
			if(i%2==1)
			{
				paint.setColor(Color.RED);  // what will be the color of painting
				paint.setStyle(Style.FILL); //
			}
			else
			{
				paint.setColor(Color.BLUE);  // what will be the color of painting
				paint.setStyle(Style.FILL); //
			}
			
			if(brick[i].getFlag())
			{
				canvas.drawRect(brick[i].getx(),brick[i].gety(),brick[i].getxx(),brick[i].getyy(), paint); // x1=100 , y1=100 , x2=200 , y2=200
			}
			
		}
		//canvas.drawRect(100, 100, 200, 200, paint); // x1=100 , y1=100 , x2=200 , y2=200
	}
	
	public void read()
	{
		BufferedReader reader=null;
		
		try
		{
			reader=new BufferedReader(
					new InputStreamReader(getContext().getAssets().open("input.txt"))
					);
			
			String line;
			float yyy=80;
			int indexindex=0;
			while((line=reader.readLine())!=null)
			{
				if(stageNo==1)
				{
					
					if(line.toString().equals("a"))
					{
						while((line=reader.readLine())!=null)
						{
							if(line.toString().equals("b"))break;
							
							
							brick_file_info[indexindex++]=Float.valueOf(line.toString());
							//canvas.drawText(String.valueOf(brick_file_info[indexindex-1]), 40,yyy+=40, paint);
						}
					}
				}
				else if(stageNo==2)
				{
					
					
					if(line.toString().equals("b"))
					{
						while((line=reader.readLine())!=null) 
						{
							brick_file_info[indexindex++]=Float.valueOf(line.toString());
							//canvas.drawText(line.toString(), 40,yyy+=40, paint);
						}
					}
				}
				
				//Toast.makeText(getContext(), "aa",Toast.LENGTH_LONG);
			}
		}
		catch (Exception e) {
			//Toast.makeText(getContext(), "aa",Toast.LENGTH_LONG);
			// TODO: handle exception
		}
	}
	public void gameOver(){
		
		if(collision_num>=num_of_brick||gameInformation.getLife()==0)
		{
			
			
			paint.setColor(Color.WHITE);
            canvas.drawRect(0, 0, canvas.getWidth(), canvas.getHeight(), paint);   
            
            paint.setColor(Color.BLUE);
            paint.setTextSize(30);
            paint.setFakeBoldText(true);
            canvas.drawText("game over \n score "+gameInformation.getScore(),canvas.getWidth()/2-150,canvas.getHeight()/2,paint);
            //canvas.drawText("FINAL SCORE: "+gameInformation.getScore(),canvas.getWidth()/2-150,canvas.getHeight()/2+60,paint);
            
            if(collision_num>=num_of_brick)
            {
            	
            	
            	if(stageNo==1)
            	{
            		isstage1fullover=10;
            		
            	}
            	                
                
            }
            try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
        	((DxBallActivity)getContext()).finish();
			
	        /*
	        try {
	        	Thread.sleep(2000);
	        	paint.setColor(Color.WHITE);
	            canvas.drawRect(0, 0, canvas.getWidth(), canvas.getHeight(), paint);   
	            
	            paint.setColor(Color.RED);
	            paint.setTextSize(50);
	            paint.setFakeBoldText(true);
		        canvas.drawText("Game Over \n Score : "+gameInformation.getScore(),canvas.getWidth()/2-50,canvas.getHeight()/2,paint);
		        collision_num=0;
		        
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
	    	((DxBallActivity)getContext()).finish();
	    	*/
		}
		
    	
    	
    	

	}
    @Override
    public boolean onTouchEvent(MotionEvent event) {
    
    	float touchleft = event.getX();
    	
    	//Log.d(tag, msg)
		
		//canvas.drawText(String.valueOf(touchx),canvas.getWidth()/2-60,40,paint);
		if(touchleft>=(Bar.getBarLeft()+Bar.getBarHeight()/2)){
			
			if(Bar.getBarLeft()+Bar.getBarWidth()<w)
			{
				Bar.setBarLeft(Bar.getBarLeft()+15);
			}
			
		}
		if(touchleft<(Bar.getBarLeft()+Bar.getBarHeight()/2)){
			
			if(Bar.getBarLeft()>0)
			{
				Bar.setBarLeft(Bar.getBarLeft()-15);
			}
			
		}
		
		return true;

    }
    
	
	public GameCanvas(Context context) {
		super(context);
		paint = new Paint();
		//File dir = new File(path);
       // dir.mkdirs();
		
		
	}
	
	
	public void initialize_brick()
	{
		float[] x1=new float[num_of_brick];
		float[] y1=new float[num_of_brick];
		float[] x2=new float[num_of_brick];
		float[] y2=new float[num_of_brick];
		
		brickx=(canvas.getWidth()-brick_file_info[2]-brick_file_info[2])/brick_file_info[0];
		bricky=brick_file_info[2];
		int brick_num=0;
		
		
		for(int row=0;row<num_of_brick/brick_file_info[0];row++)
		{
			
			for(int col=0;col<brick_file_info[0];col++)
			{
				
				x1[brick_num]=brick_file_info[1]+(brickx*col);
				y1[brick_num]=h/4+(bricky*row);
				x2[brick_num]=brick_file_info[1]+(brickx*(col+1));
				y2[brick_num]=h/4+(bricky*(row+1));
				
				brick[brick_num]=new DxBallBrick(x1[brick_num],y1[brick_num],x2[brick_num],y2[brick_num]);
				brick_num++;
				
				
				/*
				for(int i=1;i<num_of_brick;i++)
				{
					x1[i]=x1[i-1]+brickx;
					y1[i]=y1[i-1]; 
				}
				
				
				
				for(int i=0;i<num_of_brick;i++)
				{
					x2[i]=x1[i]+brickx;
					y2[i]=y1[i]+bricky;
				}
				
				for(int i=0;i<num_of_brick;i++)
				{
					Log.d(Integer.toString(i)+"    brick info:  ",Float.toString(x1[i])+"   "+Float.toString(y1[i])+"    "+Float.toString(x2[i])+"    "+Float.toString(y2[i]));
					
					brick[i]=new DxBallBrick(x1[i],y1[i],x2[i],y2[i]);
				}
				*/
			}
			
			
			
		}
		
		
	}
	

}
